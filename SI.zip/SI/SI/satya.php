<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = "localhost"; // MySQL server host
    $username = "root"; // MySQL username
    $password = ""; // MySQL password
    $database = "si"; // Database name

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    

    $lname= $_POST["lname"];
    $email= $_POST["mail"];
    $message= $_POST["message"];
    $additional= $_POST["addtional"];
    
    
   $sql = "INSERT INTO si(lastname,email,message,add_details) VALUES (?,?, ?,?)";
    $stmt = $conn->prepare($sqSl);

    if ($stmt) {
        $stmt->bind_param("ssss",$lname, $email,$message,$additional);

        if ($stmt->execute()) {
            echo "Your message is sent!!!.";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>